"""
Student's Name: !!!Write your name here!!!
ID: !!!Write your id here!!!
P12
Food consumption.
"""

if __name__ == '__main__':
    sex = input('Are you male(M) or female(F)?')

    # Write your code here

    # This is a dummy code
    food_kcal = 0

    print('That is', food_kcal)
    print("That would be it for your daily diet.")
    print("Be moderate on your diet. Stay healthy.")