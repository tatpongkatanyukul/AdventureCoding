"""
Write a program to ask a user for his/her height (in cm),
convert it to feet (ft) and inches (in) and report them back.
Note 2.54 cm = 1 in; 12 in = 1 ft.
"""

if __name__ == '__main__':

    # Write your program here
    # Use the texts provided as fit

    input('How tall are you (in cm)? ')

    feet = 0 # dummy answer
    inch = 0 # dummy answer

    # Do not edit below this line.
    # ------------------------------------------------------
    print("That is around %d ft %d in."%(feet, round(inch)))