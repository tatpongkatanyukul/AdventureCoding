"""
Student's name:
id:
P17
Sigmoid
"""

# Write your code here
# ... 

# Do not edit below this line
# ===================================
if __name__ == '__main__':
    a = float(input('a:'))
    print('sigmoid({:.2f})={:.4f}'.format(a, sigmoid(a)))