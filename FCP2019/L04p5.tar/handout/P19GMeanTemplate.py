"""
Geometric mean
"""

if __name__ == '__main__':

    gmean = 0 # dummy answer

    # do not edit below this line
    # ===========================================
    print('Geometric mean = {:.6f}'.format(gmean))