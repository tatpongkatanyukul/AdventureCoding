"""
Student's name:
id:
P18
Relu
"""

# !!! Write your function here !!!

# Do not edit below this line
# ===================================
if __name__ == '__main__':
    a = float(input('a:'))
    print('relu({:.2f})={:.4f}'.format(a, relu(a)))