"""
Student's name:
id:
P13
Write a program to calculate a maximum current through a machine.
Given a machine operating at 220 volt,
ask a user for its maximum power consumption,
calculate its maximum current, and report the calculation.
Note: (max current) = (max power)/(operating volt).
"""

if __name__ == '__main__':

    # Write your code here ....
    # ....

    i = 0 # dummy answer

    print('At 220 V, max current = %.4f A'%i) # Keep this line untouched


