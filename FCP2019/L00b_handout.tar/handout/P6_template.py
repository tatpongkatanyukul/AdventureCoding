"""
P6 Template
"""

investment = 0 # Dummy

production = 0 # Dummy

wholesale = 0 # Dummy

income = 0 # Dummy

balance = 0 # Dummy

sheet = "Balance = income ({:,.2f}) - investment ({:,.2f}) = {:,.2f} baht/rai"

print(sheet.format(income, investment, balance))
