"""
Cast Away chance to be found.
A lone plane-crash survivor on an uninhabited island tries to figure out
his chance to be found by a search team. He was on a plane traveling at
speed v mph. The plane lost its contact for T hours before crash.
Write a program to calculate a search area for this cast-away:
ask a user for plane speed v (in mph) and
time T between the plane last contact and its crash,
calculate the search area and report the finding
(as well as put it in perspective: Thailand size = 513,120 sq. km. = 198,120 sq. mi.)
Note: (1) search area = pi * r^2; (2) r = v * T.
"""

import math

v = float(input('Plane speed (mph):'))
T = float(input('Interval between crash and the last contact (h):'))

Area = 0 # Dummy

Area_Perspective = 0 # Dummy

report = "Search area = {:,.2f} sq.mi."
print(report.format(Area))

Thailand = 198120
perspective = "That's {:,.2f} time(s) the size of Thailand."
print(perspective.format(Area_Perspective))