"""
given a cover price p,
(1) a retailer will charge %r from the cover price:
retailer share = p * r/100;
(2) p = retailer share + author share + \
printing cost + shipping cost (per book)
"""

print_cost = float(input("Printing cost(baht/book): "))
shipping_cost = float(input("Shipping cost(baht/50 books): "))
retail = float(input("Retailer % (%cover price): "))
author_share = float(input("Author share (baht/book): "))

cover_price = 0 # Dummy

print("Cover price should be {:,.2f}".format(cover_price))
