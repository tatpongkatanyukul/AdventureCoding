"""
P2 Simple function with return
"""

def compute_round(num):

	pass  # dummy code
	# Write your code here
	return 0
	
	
if __name__ == '__main__':
	compute_round(1.02)
	compute_round(19.88)
	print(compute_round(3.3333))
	print(compute_round(750.64))
	print(compute_round(42))
	