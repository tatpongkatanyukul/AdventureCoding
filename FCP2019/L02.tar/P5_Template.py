"""
P5. Write 3 functions.
(1) Function get_input is to ask a user to enter an amount in gallon
and return that value as an integer.
(2) Function gallon_equiv is to take a number of gallons
and return an equivalent amount in litre.
(3) Function report_conversion takes numbers of gallons and litres
and put out a friendly display on screen.
Note: 1 US Gallon = 3.7854 L = 0.003785 cu. m.
"""

# Do not edit above this line.
# ------------------------------------------------


#  ... Your functions will be here. ...


# [!!! Mark 2 !!!]
# Do not edit below this line.
# ------------------------------------------------

if __name__ == '__main__':
    n = get_input()
    report_conversion(n, gallon_equiv(n))
