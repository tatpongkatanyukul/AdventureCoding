"""
P1 Simple function with no return
"""

def print_round(num):

	# write your code here
	pass # dummy code

if __name__ == '__main__':
	print_round(3.3333)
	print_round(750.64)
	print_round(42)
	