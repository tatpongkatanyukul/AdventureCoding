"""
P4. Write 2 functions: (1) area_conversion to take integer argument
as an area in a number of rai’s, convert it to hectare, acre, and sq. m.
and print them out
and (2) get_user_input to ask user for entering a size of his/her area
in rai, convert it to integer (making it ready for area_conversion),
and return that integer value out.
Note: 1 rai = 1600 sq. m. = 0.3954 acre = 0.16 hectare.
"""

# Do not edit above this line.
# ------------------------------------------------

# .... your functions will be here ....

# Define function area_conversion here
# param:
#   rai
# no return


# Define function get_user_input here
# no param
# return:
#   integer from what user entered



# [!!! Mark 2 !!!]
# Do not edit below this line.
# ------------------------------------------------

if __name__ == '__main__':
    area_conversion(get_user_input())
