import math

x1 = int(input('x1:'))
# Write your code here

# x1, y1: coordinates of point 1
# x2, y2: coordinates of point 2
# dist: distance between the two points

dist = 0

## Do not edit below this line
## ----------------------------------

print('distance=', round(dist, 2))