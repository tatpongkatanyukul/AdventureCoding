"""
Write a program to compute a compounding interest.
A program takes 3 inputs: average interest, a number of years, a capital.
Then, it calculates the compounding balance in the end.
"""

def calc_int_bal(start_bal, num_years, aint):

    ## Do not change anything above this line.
    ## ----------------------------------------

    # aint: average interest rate
    # num_years: a number of years
    # start_bal: starting balance or capital
    # end_bal: balance in the end

    end_bal = 0

    # Fill in your code to have end_bal the correct value.



    ## Do not change anything below this line.
    ## ----------------------------------------

    return end_bal



if __name__ == '__main__':
    capital = float(input('starting balance:'))
    n_years = int(input('# years:'))
    apr = float(input('average interest rate:'))

    bal = calc_int_bal(capital, n_years, apr)

    print("{:,.2f}".format(bal))