"""
Write a smart cashier program to calculate numbers of banknotes and coins to give change to a customer.
The program takes 2 inputs: price and an amount a customer pays.
Then, it calculates numbers of banknotes and coins for the change
and print out the numbers of 500-baht bills, 100-baht bills, 50-baht bills, 20-baht bills, 10-baht coins, 5-baht coins,
and 1-baht coins in order.

"""

def calc_num_bills(price, pay):

    ## Do not change anything above this line.
    ## ----------------------------------------

    # price: an amount of the product
    # pay: an amount the customer gave
    # change: an amount of change a cashier is to return to a customer

    change = 0

    # B500: a number of 500B bills
    # B100: ~ 100B bills
    # B50:  ~ 50B bills
    # B20:  ~ 20B bills
    # B10:  ~ 10B coins
    # B5:   ~ 5B coins
    # B1:   ~ 1B coins

    B500 = 0
    B100 = 0
    B50 = 0
    B20 = 0
    B10 = 0
    B5 = 0
    B1 = 0

    # Fill in your code to have change, B500, ..., B1 the correct values.



    ## Do not change anything below this line.
    ## ----------------------------------------

    return (change, B500, B100, B50, B20, B10, B5, B1)



if __name__ == '__main__':
    price = int(input('price:'))
    pay = int(input('a customer gives:'))

    r = calc_num_bills(price, pay)

    print('change =', r[0])
    print(r[1:])