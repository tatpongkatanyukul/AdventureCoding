Antique yet up-to-the-minute, 
familiar yet unrecognisable, 
outwardly urban but quintessentially rural, 
conservative yet path-breaking, 
space-age but old-fashioned, 
China is a land of mesmerising contradictions.