

fav_num = input("What is your favorite number? ")
print(fav_num, "is a good number.")
