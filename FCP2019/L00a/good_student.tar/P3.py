
your_like = input("What do you like most at school? ")
print("I am glad you like", your_like)