

age = int(input("How old are you? "))
print("You will be graduated at", age + 3)
