print("Success is no accident. It is hard work,")
print("perseverance, learning, studying, sacrifice")
print("and most of all, love of what you are doing or learning to do.")
print("--- Pele")