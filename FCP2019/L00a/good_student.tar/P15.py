
print("**//\\\\\\\\*****")
print("*|*o**o*|****")
print("*/******\****")
print("|**\__/**|***")
print("**\-++-/*****")
print("Do you have fun?")
