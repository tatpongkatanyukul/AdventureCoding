a = int(input("a: "))
b = int(input("b: "))
# print("a/b =", a / b)
print("a/b gives a quotient of", a//b, "and a remainder of", a%b)