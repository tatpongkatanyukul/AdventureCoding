
print('... what I type inside the quote is printed out exactly ... with a space; with  double  spaces   withoutanyspace ...')