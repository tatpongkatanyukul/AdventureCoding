

word = input("word 1: ")
num = int(input("number to repeat: "))

print("repeat (word 1) =", num*word)
