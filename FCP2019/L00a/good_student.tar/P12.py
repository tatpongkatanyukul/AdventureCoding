
w1 = input("word 1: ")
w2 = input("word 2: ")
print("(word 1 + word 2) =", w1 + w2)
