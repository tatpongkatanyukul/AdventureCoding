a = int(input("a: "))
b = int(input("b: "))
print("a - b =", a - b)
